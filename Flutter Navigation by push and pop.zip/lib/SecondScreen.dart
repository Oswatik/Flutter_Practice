import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'ThirdScreen.dart';

class SecondScreen extends StatelessWidget {
  //final String name;
  //final int age;

  //const SecondScreen({
    //Key? key,
    //required this.name,
    //required this.age,
  //}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text("routing app"),
        centerTitle: true,
        actions: [
          IconButton(
          onPressed: (){
            print("Button Pressed");
          },
          icon: Icon(Icons.headphones), 
          )],
      ),
      drawer: Drawer(
        child: Container(
          color: Colors.deepOrangeAccent[200],
          child: ListView(
            children: [
              DrawerHeader(child: Icon(Icons.heart_broken_outlined)),
              ListTile(
                title: Center(child: Text('Love')),
                leading: Icon(Icons.lock),
              ),
              ListTile(
                title: Center(child: Text('Love')),
                leading: Icon(Icons.lock),
              ),
              ListTile(
                title: Center(child: Text('Love')),
                leading: Icon(Icons.lock),
              ),
              ListTile(
                title: Center(child: Text('Love')),
                leading: Icon(Icons.lock),
              ),
            ],
          ),
        ),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            print("wapas jayega");
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => ThirdScreen(
                  name:"ana",
                  age: 20,
                )
              )
            );
            // Navigator.of(context).pop(
            //   MaterialPageRoute(
            //    builder: context => FirstScreen()
            //   )
            //);
          },
          child: Text(
            "last screen",
            style: TextStyle()),
          //style: ElevatedButton.styleFrom(padding: EdgeInsets.all(20)),
        ),
      ),
    );
  }
}
