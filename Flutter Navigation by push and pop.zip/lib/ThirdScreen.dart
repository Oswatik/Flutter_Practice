import 'package:flutter/material.dart';
import 'SecondScreen.dart';

class ThirdScreen extends StatelessWidget {
  final String name;
  final int age;

  ThirdScreen({
    Key?key, 
    required this.name, 
    required this.age
    //required this.name,
    //required this.age,
  }) : super(key: key)
  //const ThirdScreen({super.key});
{}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      drawer: Drawer(),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("bdvb idhbc"),
            ElevatedButton(
              onPressed: (){
                Navigator.of(context).pop();
                  //MaterialPageRoute(
                    //builder: (context) => SecondScreen()
                  //)
                //);
              },
              child: Text(name)
            )
          ],
        ),
      ),
    );
  }
}