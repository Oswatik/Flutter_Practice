import 'package:flutter/material.dart';
import 'SecondScreen.dart';

class FirstScreen extends StatelessWidget {
  const FirstScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text("1st Page"),
        centerTitle: true,
        backgroundColor: Colors.deepPurple[200],
        actions: [IconButton(
          onPressed: (){},
          icon: Icon(Icons.production_quantity_limits),
        )],
      ),
      drawer: Drawer(
        child: Container(
          color: Colors.deepPurple,
          child: ListView(
            children: [
              DrawerHeader(
              child: Icon(Icons.broken_image),
            ),
               ListTile(
                title: Center(child: Text('Love')),
                leading: Icon(Icons.lock),
                ),
                ListTile(
                title: Center(child: Text('Love')),
                leading: Icon(Icons.lock),
                ),
                ListTile(
                title: Center(child: Text('Love')),
                leading: Icon(Icons.lock),
                ),
                ListTile(
                title: Center(child: Text('Love')),
                leading: Icon(Icons.lock),
                ),
            ],
          ),
        ),

      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Button",
              style: TextStyle(
                fontSize: 50
              ),
              ),
            ElevatedButton(
              onPressed: (){
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => SecondScreen()
                  )
                );

              },
              child: Text("Second Page"),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.all(20)
              ),
            ),
          ],
        ),
      )
    );
  }
}